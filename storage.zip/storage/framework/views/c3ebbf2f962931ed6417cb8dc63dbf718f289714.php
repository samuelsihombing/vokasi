<?php if (isset($component)) { $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48 = $component; } ?>
<?php $component = App\View\Components\WebLayout::resolve(['title' => 'Tentang Kami'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\WebLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .card {
            width: 280px !important;
            flex-basis: 280px !important;
            align-self: stretch;
        }
        .card-img {
            width: 150px;
            height: 150px;
            margin-left: auto;
            margin-right: auto;
            border-radius: 50%;
            object-fit: cover;
            object-position: top center;
        }
        .card-text {
            font-size: 14px
        }
        .bg-gray-400 {
            background-color: #e2e8f0;
        }
    </style>
    <?php echo $__env->make('themes.web.styling.timeline_styling', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="content">
        <div class="content-wrap">
        <div class="container-fluid">

            <div class="position-relative">

                

                <div id="posts" class="post-grid grid-container row post-timeline" data-basewidth=".entry:not(.entry-date-section):eq(0)">

                    <div class="entry entry-date-section col-12 mb-0" id="sejarah">
                        <span>SEJARAH KAMI</span>
                    </div>
                    <?php if($history->count()): ?>
                    <section class="timeline">
                        <ul>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li id="list-item-<?php echo e($no++); ?>">
                                <div id="content-item-<?php echo e($no++); ?>" class="content text-dark">
                                    <h2>
                                        <time><?php echo e($item->year); ?></time>
                                    </h2>
                                    <p><?php echo $item->desc; ?></p>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </section>
                    <?php else: ?>
                    <div class="col-md-6 mx-auto mt-5">
                        <div class="alert alert-primary text-center" role="alert">
                            <i class="bi-exclamation-circle fs-5 me-2"></i> Tidak ada sejarah yang tersedia.
                        </div>
                    </div>
                    <?php endif; ?>

                </div>

            </div>
        </div></div>

        <div style="padding-top: 30px; background: #003966" id="visi-misi">
            <div class="container pb-5">
                <style>
                    @import url('<?php echo e(asset("web/css/default-list.css")); ?>');
                </style>
                <div class="entry entry-date-section col-12 mb-3">
                    <span>Visi dan Misi</span>
                </div>
                <div class="row g-5">
                    <div class="col-md-6">
                        <h4 class="text-white fw-bold mb-3">Visi</h4>
                        <div id="color-white-important" class="text-white"><?php echo $vision->visi ?? '<p class="text-white">Visi belum ditambahkan</p>'; ?></div>
                    </div>
                    <div class="col-md-6">
                        <h4 class="text-white fw-bold mb-3">Misi</h4>
                        <div id="color-white-important" class="text-white">
                            <?php echo $vision->misi ?? '<p class="text-white">Misi belum ditambahkan</p>'; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container pb-5" id="struktur">
            <div class="entry entry-date-section col-12 mt-5 mb-0">
                <span class="border-0">Struktur Organisasi</span>
                <?php if($structure->count()): ?>
                <div class="d-flex justify-content-center">
                    <div class="card bg-gray-400 m-2">
                        <img src="<?php echo e($structure[0]->thumbnail ? Storage::url($structure[0]->thumbnail) : asset('web/images/no-img-profile.jpg')); ?>" class="card-img my-3">
                        <div class="card-body pt-0">
                            <div class="card-text fw-semibold"><?php echo e($structure[0]->position); ?></div>
                            <div class="card-text"><?php echo $structure[0]->name; ?></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-wrap justify-content-center align-items-center">
                    <?php $__currentLoopData = $structure->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card bg-gray-400 m-3">
                        <img src="<?php echo e($item->thumbnail ? Storage::url($item->thumbnail) : asset('web/images/no-img-profile.jpg')); ?>" class="card-img my-3">
                        <div class="card-body pt-0">
                            <div class="card-text fw-semibold"><?php echo e($item->position); ?></div>
                            <div class="card-text"><?php echo $item->name; ?></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <div class="col-md-6 mx-auto mt-4">
                    <div class="alert alert-primary text-center" role="alert">
                        <i class="bi-exclamation-circle fs-5 me-2"></i> Struktur organisasi belum ditambahkan.
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <script>
        document.querySelectorAll('#color-white-important *').forEach(function(node) {
            node.style.color = 'white !important';
        });

        function adjustListHeights() {
            var listItemElements = document.querySelectorAll('[id^="list-item-"]');
            var contentItemElements = document.querySelectorAll('[id^="content-item-"]');

            for (var i = 0; i < listItemElements.length; i++) {
                var listItem = listItemElements[i];
                var contentItem = contentItemElements[i];
                var contentHeight = contentItem.offsetHeight;

                listItem.style.height = contentHeight + 'px';
            }
        }


        window.onload = function() {
            adjustListHeight();
        };

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48)): ?>
<?php $component = $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48; ?>
<?php unset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/web/about/main.blade.php ENDPATH**/ ?>