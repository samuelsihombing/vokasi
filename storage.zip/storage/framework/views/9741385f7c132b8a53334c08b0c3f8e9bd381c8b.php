<table class="table align-middle table-row-dashed fs-6 gy-5" id="kt_customers_table">
    <thead>
        <tr class="text-start text-gray-400 fw-bold fs-7 text-uppercase gs-0">
            <th class="w-10px pe-2">
                <div class="form-check form-check-sm form-check-custom form-check-solid me-3">
                    <input class="form-check-input" type="checkbox" data-kt-check="true" data-kt-check-target="#kt_customers_table .form-check-input" value="1" />
                </div>
            </th>
            <th class="min-w-125px">Gambar</th>
            <th class="min-w-125px">Judul</th>
            <th class="min-w-125px">Url Tujuan</th>
            <th class="min-w-125px">Aktif/Non Aktif</th>
            <th class="min-w-125px">Dibuat Tanggal</th>
            <th class="text-end min-w-70px">Aksi</th>
        </tr>
    </thead>
    <tbody class="fw-semibold text-gray-600">
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <div class="form-check form-check-sm form-check-custom form-check-solid">
                    <input class="form-check-input" type="checkbox" value="1" />
                </div>
            </td>
            <td>
                <a href="<?php echo e(route('office.appearance.faculty-items-section.edit',$item->id)); ?>" class="menu-link"><img
                    src="<?php echo e(Storage::url($item->thumbnail)); ?>"
                    data-src="<?php echo e(Storage::url($item->thumbnail)); ?>"
                    class="lozad rounded"
                    alt="" style="width: 150px; height: 100px; object-fit: cover;"
                /></a>
            </td>
            <td>
                <a href="<?php echo e(route('office.appearance.faculty-items-section.edit',$item->id)); ?>" class="menu-link text-gray-600 text-hover-primary mb-1"><?php echo e($item->title); ?></a>
            </td>
            <td><?php echo e($item->url ?? ''); ?></td>
            <td>
                <?php if($item->is_active == 1): ?>
                <span class="badge badge-light-success py-3 px-4 fs-7">Aktif</span>
                <?php else: ?>
                <span class="badge badge-light-danger py-3 px-4 fs-7">Tidak Aktif</span>
                <?php endif; ?>
            </td>
            <td><?php echo e($item->created_at->format('d F Y, H:i A')); ?></td>
            <td class="text-end text-nowrap">
                <a href="<?php echo e(route('office.appearance.faculty-items-section.edit',$item->id)); ?>" class="menu-link btn btn-icon btn-warning"><i class="las la-edit text-black fs-2"></i></a>
                <?php if($item->is_active == 1): ?>
                <button type="button" title="Non Aktifkan" id="tombol_non_aktif" data-redirect-url="<?php echo e(route('office.appearance.faculty-explore-section.index')); ?>" onclick="handle_is_active('PATCH','<?php echo e(route('office.appearance.faculty-items-section.update',$item->id)); ?>','#tombol_non_aktif', 0);" class="btn btn-icon btn-danger"><i class="las la-times fs-2"></i></button>
                <?php else: ?>
                <button type="button" title="Aktifkan" id="tombol_aktif" data-redirect-url="<?php echo e(route('office.appearance.faculty-explore-section.index')); ?>" onclick="handle_is_active('PATCH','<?php echo e(route('office.appearance.faculty-items-section.update',$item->id)); ?>','#tombol_aktif', 1);" class="btn btn-icon btn-success"><i class="las la-check fs-2"></i></button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('themes.app.pagination')); ?>

<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/app/appearance/home/faculty_item_section/list.blade.php ENDPATH**/ ?>