<style>
    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    @media (min-width: 768px) {
        .card {
            padding: 30px;
            width: 500px;
            height: 550px;
        }
    }
</style>

<?php if (isset($component)) { $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48 = $component; } ?>
<?php $component = App\View\Components\WebLayout::resolve(['title' => 'Login'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\WebLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 d-flex justify-content-center">
                <div class="card">
                    <div class="d-flex justify-content-center">
                        <div style="text-align: center">
                            <img src="<?php echo e(asset('web/images/logodel.png')); ?>" alt="Logo IT Del" style="width: 70px; height:auto">
                            <h3 class="mt-4">Sistem Informasi Fakultas Vokasi</h3>
                        </div>
                    </div>
                    <hr>
                    <div class="card-body">
                        <form action="<?php echo e(route('web.auth.login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label for="email" class="col-md-12 col-form-label text-md-start"><b><?php echo e(__('Email')); ?></b>
                                </label>

                                <div class="col-md-12">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="password" class="col-md-12 col-form-label text-md-start font-weight-bold"><b><?php echo e(__('Password')); ?></b></label>

                                <div class="col-md-12">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php echo e(session('error') != null ? 'is-invalid' : ''); ?>" name="password" required autocomplete="current-password">
                                    <strong class="invalid-feedback"><?php echo e(session('error')); ?></strong>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3" style="padding-top: 20px">
                                <div class="col-md-6 d-flex justify-content-start" style="padding-left: 30px;">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                        <label class="form-check-label" for="remember">
                                            <?php echo e(__('Ingat saya')); ?>

                                        </label>
                                    </div>
                                </div>

                                <div class="col-md-6 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary px-4">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48)): ?>
<?php $component = $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48; ?>
<?php unset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/web/auth/login.blade.php ENDPATH**/ ?>