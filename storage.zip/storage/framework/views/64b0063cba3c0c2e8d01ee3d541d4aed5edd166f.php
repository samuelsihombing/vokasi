<?php if (isset($component)) { $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48 = $component; } ?>
<?php $component = App\View\Components\WebLayout::resolve(['title' => 'Dosen - '.e($dosen->name ?? '').''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\WebLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('themes.web.styling.show_civitas_styling', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Content ============================================= -->
    <section id="content" style="background: #ebe8e879" class="my-font">
        <div class="row align-items-center bg-white m-0">
            <div class="col-3">
                <a href="<?php echo e(route('web.civitas.dosen')); ?>" class="menu-link my-link text-dark text-small fw-light">
                    <i class="fa-solid fa-arrow-left me-3"></i>
                    kembali<span class="d-none d-lg-inline"> ke halaman dosen</span>
                </a>
            </div>
            <div class="col-9">
                <ul class="nav my-tabs flex-nowrap text-nowrap border-0 mt-0 ms-5 overflow-auto">
                    <li class="nav-item">
                        <a class="nav-link active px-5 py-3 text-dark text-uppercase" data-bs-toggle="tab" href="#tentang">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-5 py-3 text-dark text-uppercase" data-bs-toggle="tab" href="#penelitian">Hasil Penelitian</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-5 py-3 text-dark text-uppercase" data-bs-toggle="tab" href="#pendanaan">Pendanaan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link px-5 py-3 text-dark text-uppercase" data-bs-toggle="tab" href="#pengajaran">Pengajaran dan Pembimbingan</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="content-wrap" style="padding-top: 25px !important;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="card my-card border-0">
                            <div class="card-body py-4">
                                <div class="d-flex justify-content-center align-items-cemter mt-2">
                                    <img src="<?php echo e($dosen->avatar ? Storage::url($dosen->avatar) : asset('web/images/no-img-profile.jpg')); ?>" class="my-image rounded rounded-circle">
                                </div>
                                <div class="text-center mt-3 border-bottom-dashed">
                                    <div class="text-muted fw-light text-uppercase" style="font-size: 12px"><?php echo e($dosen->position ?? ''); ?></div>
                                    <h4 class="text-center fw-500 mb-3"><?php echo e($dosen->name ?? '-'); ?></h2>
                                </div>
                                <div class="text-center text-muted mt-2 border-bottom-dashed pb-2">
                                    <div>NIDN : <?php echo e($dosen->nidn ?? '-'); ?></div>
                                    <div>SINTA ID : <?php echo e($dosen->sinta_id ?? '-'); ?></div>
                                </div>
                                <div class="text-start text-muted mt-2 border-bottom-dashed pb-3 pt-2 px-2">
                                    <i class="fa-solid fa-building-columns me-3"></i>  <?php echo e($dosen->user_category->name ?? '-'); ?>

                                </div>
                                <div class="text-start text-muted mt-2 border-bottom-dashed pb-3 pt-2 px-2">
                                    <i class="fa-solid fa-phone me-3"></i>  <?php echo e($dosen->phone ?? '-'); ?>

                                </div>
                                <div class="text-start text-muted mt-2 border-bottom-dashed pb-3 pt-2 px-2">
                                    <i class="fa-solid fa-envelope me-3"></i>  <?php echo e($dosen->email ?? '-'); ?>

                                </div>
                                <div class="text-start text-muted mt-2 border-bottom-dashed pb-3 pt-2 px-2">
                                    <i class="fa-solid fa-link me-3"></i>  <?php echo e($dosen->url ?? '-'); ?>

                                </div>
                            </div>
                            <a href="<?php echo e(route('office.auth.index')); ?>" class="are-you-is">
                                <div class="d-flex justify-content-center align-items-center">
                                    <i class="fa-solid fa-user-pen fs-4 me-2"></i>
                                    <div>
                                        <div class="fs-6">Apakah Anda <?php echo e($dosen->name); ?> ?</div>
                                        <div class="fw-light mt-1">Edit Profilmu *</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-9 mt-4 mt-lg-0">
                        <div class="tab-container">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane active" id="tentang" role="tabpanel">
                                    <div class="card my-card border-0">
                                        <div class="card-body px-4">
                                            <div class="card-title text-uppercase">Bio</div>
                                            <div class="text-muted fw-light">
                                                <?php echo $dosen->bio ?? 'Belum ada deskripsi apa pun yang ditambahkan'; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <?php if($dosen->education->count() > 0): ?>
                                    <div class="card my-card border-0 mt-4">
                                        <div class="card-body px-4">
                                            <div class="card-title text-uppercase">Riwayat Pendidikan</div>
                                            <?php $__currentLoopData = $education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="fs-6"><?php echo e($item->university); ?></div>
                                            <div class="fw-light <?php echo e($loop->last ? 'mb-2' : ''); ?>"><?php echo e($item->year . ' - ' . $item->knowledge_field); ?></div>
                                            <?php if(!$loop->last): ?>
                                            <hr>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($dosen->skill != null): ?>
                                    <style>
                                        ol {
                                            display: block;
                                            list-style-type: decimal;
                                            margin-top: 0;
                                            margin-bottom: 1em;
                                            margin-left: 0;
                                            margin-right: 0;
                                            padding-left: 20px;
                                        }

                                        ul {
                                            display: block;
                                            list-style-type: disc;
                                            margin-top: 0;
                                            margin-bottom: 1em;
                                            margin-left: 0;
                                            margin-right: 0;
                                            padding-left: 20px;
                                        }

                                        li {
                                            display: list-item;
                                        }
                                    </style>
                                    <div class="card my-card border-0 mt-4">
                                        <div class="card-body px-4">
                                            <div class="card-title text-uppercase">Keahlian</div>
                                            <div class="text-muted">
                                               <?php echo $dosen->skill; ?>

                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="tab-pane" id="penelitian" role="tabpanel">
                                    <div class="card my-card border-0">
                                        <div class="card-body px-4">
                                            <div class="card-title text-uppercase">Hasil Penelitian</div>
                                            <?php if($research->count() > 0): ?>
                                                <?php $__currentLoopData = $research; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="card rounded-6 my-shadow border-0 mt-3 <?php echo e($loop->last ? 'mb-3' : ''); ?>">
                                                    <div class="card-body">
                                                        <div class="fw-semibold" style="font-size: 17px; text-transform: capitalize"><?php echo e($item->title); ?></div>
                                                        <div class="text-muted fw-light">Dipublikasikan di <?php echo e($item->published . ', ' . date('d M Y', strtotime($item->date))); ?></div>
                                                        <a href="<?php echo e($item->url ?? '#'); ?>" target="_blank" class="fw-light text-primary"><?php echo e($item->url); ?></a>
                                                        <div class="text-muted mt-1 fw-light">
                                                            <?php echo $item->desc ?? ''; ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <span class="text-muted fw-light">Belum ada hasil penelitian yang ditambahkan</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="pendanaan" role="tabpanel">
                                    <div class="card my-card border-0">
                                        <div class="card-body px-4">
                                            <div class="card-title text-uppercase">Pendanaan</div>
                                            <?php if($funding->count() > 0): ?>
                                                <?php $__currentLoopData = $funding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="card rounded-6 my-shadow border-0 mt-3 <?php echo e($loop->last ? 'mb-3' : ''); ?>">
                                                    <div class="card-body">
                                                        <span class="text-uppercase fw-light" style="font-size: 12px"><?php echo e($item->type); ?></span>
                                                        <div class="fw-semibold" style="font-size: 17px !important; text-transform: capitalize"><?php echo e($item->project_name); ?></div>
                                                        <div><?php echo e($item->organizer); ?></div>
                                                        <div class="text-muted mt-1 fw-light">
                                                            <?php echo e($item->working_area); ?>,
                                                            <?php echo e(App\Helpers\FedHelper::formatWorkingTime($item->working_time)); ?>

                                                        </div>
                                                        <div class="text-muted fw-light">
                                                            <i class="bi bi-people-fill me-2"></i>
                                                            <?php echo e($item->involved_parties); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <span class="text-muted fw-light">Belum ada Pendanaan yang ditambahkan</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="pengajaran" role="tabpanel">
                                    <div class="card my-card border-0">
                                        <div class="card-body px-4">
                                            <div class="card-title text-uppercase">Pengajaran & Pembimbingan</div>
                                            <div class="d-flex justify-content-start mb-4">
                                                <span class="text-muted me-3">Urutkan Berdasarkan:</span>
                                                <select name="category" id="filter-category" class="text-muted">
                                                    <option value="semua">Tampilkan Semua</option>
                                                    <option value="Pengajaran">Pengajaran</option>
                                                    <option value="Pembimbingan">Pembimbingan</option>
                                                </select>
                                            </div>
                                            <input type="hidden" name="dosen_id" id="dosen_id" value="<?php echo e($dosen->id); ?>">
                                            <?php if($teaching_mentoring->count() > 0): ?>
                                            <div id="card-teaching-mentoring">
                                                <?php $__currentLoopData = $teaching_mentoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="card rounded-6 my-shadow border-0 mt-3 <?php echo e($loop->last ? 'mb-3' : ''); ?>">
                                                    <div class="card-body">
                                                        <span class="text-uppercase fw-light" style="font-size: 12px"><?php echo e($item->category); ?></span>
                                                        <div class="fw-semibold" style="font-size: 17px; text-transform: capitalize"><?php echo e($item->title); ?></div>
                                                        <div class="text-muted"><?php echo $item->student_name ? 'Mahasiswa: ' . $item->student_name : ''; ?></div>
                                                        <div class="text-muted mt-1 fw-light"><?php echo e($item->year); ?></div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php else: ?>
                                            <span class="text-muted fw-light">Belum ada pengajaran dan pembimbingan yang ditambahkan</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- #content end -->

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(`#filter-category`).change(function() {
            category = $(this).val();
            var dosen_id = $(`#dosen_id`).val();
            var card = $(`#card-teaching-mentoring`);
            card.empty();
            filterTeachingMentoring(category, dosen_id);
        });

        function filterTeachingMentoring(category, dosen_id) {
            $.ajax({
                url: "/teaching-mentoring-filter",
                method: `GET`,
                data: {
                    category: category,
                    dosen_id: dosen_id
                },
                dataType: `json`,
                success: function(response) {
                    if (response.status === `success`) {
                        $(`#card-teaching-mentoring .card`).remove();
                        response.data.forEach(function(item, index) {
                            var cardHtml = `<div class="card rounded-6 my-shadow border-0 mt-3 ` + (index === response.data.length - 1 ? `mb-3` : ``) + `">` +
                                `<div class="card-body">` +
                                `<span class="text-uppercase fw-light" style="font-size: 12px">` + item.category + `</span>` +
                                `<div class="fw-semibold" style="font-size: 17px; text-transform: capitalize">` + item.title + `</div>` +
                                `<div class="text-muted">` + (item.student_name ? `Mahasiswa: ` + item.student_name : ``) + `</div>` +
                                `<div class="text-muted mt-1 fw-light">` + item.year + `</div>` +
                                `</div>` +
                                `</div>`;

                            $(`#card-teaching-mentoring`).append(cardHtml);
                        });
                    } else {
                        var message = `<span class="text-muted fw-light">Belum ada pengajaran dan pembimbingan yang ditambahkan</span>`;
                        $(`#card-teaching-mentoring`).append(message);
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                }
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48)): ?>
<?php $component = $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48; ?>
<?php unset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/web/civitas/dosen/show.blade.php ENDPATH**/ ?>