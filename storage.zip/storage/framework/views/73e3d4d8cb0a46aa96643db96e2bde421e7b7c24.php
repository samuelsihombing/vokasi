<?php
    use App\Models\Appearance\Carousel as Carousel;

    $carousels = Carousel::where('is_active', 1)->orderBy('created_at', 'desc')->whereIn('url', ['home', 'program', 'tentang', 'berita', 'civitas', 'aktivitas'])->get();

    $home_carousel = $carousels->firstWhere('url', 'home');
    $program_carousel = $carousels->firstWhere('url', 'program');
    $tentang_carousel = $carousels->firstWhere('url', 'tentang');
    $berita_carousel = $carousels->firstWhere('url', 'berita');
    $civitas_carousel = $carousels->firstWhere('url', 'civitas');
    $aktivitas_carousel = $carousels->firstWhere('url', 'aktivitas');
?>

<style>
    .h2 {
        font-size: 58px !important;
        font-weight: 500;
        line-height: 1.2;
    }
    #parent-element {
        margin-top: 2rem !important;
        margin-bottom: 0.75rem !important;
        font-size: var(--cnvs-slider-caption-p-size) !important;
    }
</style>

<section id="slider" class="slider-element slider-parallax swiper_wrapper min-vh-60 min-vh-md-100">
    <div class="slider-inner">
        <div class="swiper-container swiper-parent">
            <div class="swiper-wrapper">
                <div class="swiper-slide dark">
                    <div class="container-fluid p-0" style="background: rgba(0, 0, 0, 0.1); width: 100%; height: 100%;">
                        <div class="slider-caption slider-caption-center">
                            <?php if(request()->is('program*')): ?>
                            <h2 class="text-white fw-bold h2" data-animate="fadeInUp"><?php echo $program_carousel->title ?? ''; ?></h2>
                            <div class="text-white d-none d-sm-block" id="parent-element" data-animate="fadeInUp" data-delay="200"><?php echo $program_carousel->desc ?? ''; ?></div>
                            <?php elseif(request()->is('home')): ?>
                            <h2 class="text-white fw-bold h2" data-animate="fadeInUp"><?php echo $home_carousel->title ?? ''; ?></h2>
                            <div class="text-white d-none d-sm-block" id="parent-element" data-animate="fadeInUp" data-delay="200"><?php echo $home_carousel->desc ?? ''; ?></div>
                            <?php elseif(request()->is('tentang-kami*')): ?>
                            <h2 class="text-white fw-bold h2" data-animate="fadeInUp"><?php echo $tentang_carousel->title ?? ''; ?></h2>
                            <div class="text-white d-none d-sm-block" id="parent-element" data-animate="fadeInUp" data-delay="200"><?php echo $tentang_carousel->desc ?? ''; ?></div>
                            <?php elseif(request()->is('civitas*')): ?>
                            <h2 class="text-white fw-bold h2" data-animate="fadeInUp"><?php echo $civitas_carousel->title ?? ''; ?></h2>
                            <div class="text-white d-none d-sm-block" id="parent-element" data-animate="fadeInUp" data-delay="200"><?php echo $civitas_carousel->desc ?? ''; ?></div>
                            <?php elseif(request()->is('berita*')): ?>
                            <h2 class="text-white fw-bold h2" data-animate="fadeInUp"><?php echo $berita_carousel->title ?? ''; ?></h2>
                            <div class="text-white d-none d-sm-block" id="parent-element" data-animate="fadeInUp" data-delay="200"><?php echo $berita_carousel->desc ?? ''; ?></div>
                            <?php elseif(request()->is('aktivitas*')): ?>
                            <h2 class="text-white fw-bold h2" data-animate="fadeInUp"><?php echo $aktivitas_carousel->title ?? ''; ?></h2>
                            <div class="text-white d-none d-sm-block" id="parent-element" data-animate="fadeInUp" data-delay="200"><?php echo $aktivitas_carousel->desc ?? ''; ?></div>
                            <?php else: ?>
                            <h2 data-animate="fadeInUp">Fakultas Vokasi</h2>
                            <p class="d-none d-sm-block" data-animate="fadeInUp" data-delay="200">Create just what you need for your Perfect Website. Choose from a wide range of Elements &amp; simply put them on our Canvas.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(request()->is('home*')): ?>
                        <?php if($home_carousel !== null): ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(Storage::url($home_carousel->thumbnail)); ?>');"></div>
                        <?php else: ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/home-page.png')); ?>');"></div>
                        <?php endif; ?>
                    <?php elseif(request()->is('program*')): ?>
                        <?php if($program_carousel !== null): ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(Storage::url($program_carousel->thumbnail)); ?>');"></div>
                        <?php else: ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/tentang1.png')); ?>');"></div>
                        <?php endif; ?>
                    <?php elseif(request()->is('tentang-kami*')): ?>
                        <?php if($tentang_carousel !== null): ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(Storage::url($tentang_carousel->thumbnail)); ?>');"></div>
                        <?php else: ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/tentang1.png')); ?>');"></div>
                        <?php endif; ?>
                    <?php elseif(request()->is('civitas*')): ?>
                        <?php if($civitas_carousel !== null): ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(Storage::url($civitas_carousel->thumbnail)); ?>');"></div>
                        <?php else: ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/civitas-page.png')); ?>');"></div>
                        <?php endif; ?>
                    <?php elseif(request()->is('berita*')): ?>
                        <?php if($berita_carousel !== null): ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(Storage::url($berita_carousel->thumbnail)); ?>');"></div>
                        <?php else: ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/berita.png')); ?>');"></div>
                        <?php endif; ?>
                    <?php elseif(request()->is('aktivitas*')): ?>
                        <?php if($aktivitas_carousel !== null): ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(Storage::url($aktivitas_carousel->thumbnail)); ?>');"></div>
                        <?php else: ?>
                        <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/himatera2.jpeg')); ?>');"></div>
                        <?php endif; ?>
                    <?php else: ?>
                    <div class="swiper-slide-bg" style="background-image: url('<?php echo e(asset('web/images/tentang1.png')); ?>');"></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="slider-arrow-left"><i class="uil uil-angle-left-b"></i></div>
            <div class="slider-arrow-right"><i class="uil uil-angle-right-b"></i></div>
            <div class="slide-number"><div class="slide-number-current"></div><span>/</span><div class="slide-number-total"></div></div>
        </div>
    </div>
</section>

<script>
    var parentElement = document.getElementById('parent-element');

    var childElements = parentElement

    for (var i = 0; i < childElements.length; i++) {
    var element = childElements[i];
    element.classList.add('text-white', 'd-none', 'd-sm-block');
    element.setAttribute('data-animate', 'fadeInUp');
    element.setAttribute('data-delay', '200');
    }

</script>
<?php /**PATH C:\laragon\www\vokasi\resources\views/themes/web/slider.blade.php ENDPATH**/ ?>