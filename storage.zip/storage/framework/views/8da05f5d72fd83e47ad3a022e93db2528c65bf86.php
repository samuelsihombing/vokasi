<ul class="pagination pagination-circle pagination-outline">
    <?php if($paginator->onFirstPage()): ?>
    <li class="page-item previous disabled m-1"><a href="#" class="page-link default"><i class="previous"></i></a></li>
    <?php else: ?>
    <li class="page-item previous m-1"><a href="javascript:;" data-halaman="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link default"><i class="previous"></i></a></li>
    <?php endif; ?>
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_string($element)): ?>
        <li class="page-item disabled m-1"><a href="#" class="page-link default">...</a></li>
        <?php endif; ?>
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                <li class="page-item active m-1"><a href="javascript:;" data-halaman="<?php echo e($url); ?>" class="page-link default"><?php echo e($page); ?></a></li>
                <?php else: ?>
                <li class="page-item m-1"><a href="<?php echo e($url); ?>" data-halaman="<?php echo e($url); ?>" class="page-link default"><?php echo e($page); ?></a></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($paginator->hasMorePages()): ?>
    <li class="page-item next m-1"><a href="javascript:;" data-halaman="<?php echo e($paginator->nextPageUrl()); ?>" class="page-link default"><i class="next"></i></a></li>
    <?php else: ?>
    <li class="page-item next disabled m-1"><a href="#"  class="page-link default"><i class="next"></i></a></li>
    <?php endif; ?>
</ul><?php /**PATH D:\xampp\htdocs\vokasi\resources\views/themes/app/pagination.blade.php ENDPATH**/ ?>