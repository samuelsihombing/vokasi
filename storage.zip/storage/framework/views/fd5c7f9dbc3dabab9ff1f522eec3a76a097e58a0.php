<?php
$themes = \App\Models\Appearance\Theme::where('is_admin',false)->where('is_active',true)->first();
// dd($themes);
$logo = \App\Models\Setting\Config::where('key','APP_LOGO')->first();
// $layout = $themes->layout->where('type','office_layout')->where('is_active',true)->first();
?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <?php echo $__env->make('themes.web.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body class="stretched">
        <div id="wrapper" class="cms_web">

            <?php if(!request()->is('auth')): ?>
                <!-- Header ============================================= -->
                <?php echo $__env->make('themes.web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- #header end -->
                <?php if(request()->is('civitas/dosen/*') || request()->is('civitas/staf/*')): ?>
                <?php else: ?>
                    <?php echo $__env->make('themes.web.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Content ============================================= -->
            <div class="cms_app">
                <?php echo e($slot); ?>

            </div>
            <!-- #content end -->
            <?php if(!request()->is('auth')): ?>
                <!-- Footer ============================================= -->
                <?php echo $__env->make('themes.web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- #footer end -->
            <?php endif; ?>
        </div>
        <div id="gotoTop" class="uil uil-angle-up"></div>

		<?php echo $__env->make('themes.web.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('custom_js'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\vokasi\resources\views/themes/web/main.blade.php ENDPATH**/ ?>