<?php
    $logo = \App\Models\Setting\Logo::where('is_active', 1)->first();
    $logo_thumbnail = null;
    if ($logo) {
        $logo_thumbnail = $logo->thumbnail ? Storage::url($logo->thumbnail) : null;
    }
?>

<header id="header" data-sticky-shrink="false">
    <div id="header-wrap" class="shadow">
        <div class="header-row">

            <!-- Logo
            ============================================= -->
            <div id="logo">
                <div style="height: 50px !important" class="ms-4">
                    <a href="<?php echo e(route('web.home')); ?>">
                        <img class="logo-default" style="height: 50px !important" srcset="<?php echo e($logo_thumbnail ?? asset('web/images/logodel.png')); ?>, <?php echo e($logo_thumbnail ?? asset('web/images/logodel.png')); ?>" src="<?php echo e($logo_thumbnail ?? asset('web/images/logodel.png')); ?>" alt="Canvas Logo">
                        <img class="logo-dark" style="height: 50px !important" srcset="<?php echo e($logo_thumbnail ?? asset('web/images/logodel.png')); ?>, <?php echo e($logo_thumbnail ?? asset('web/images/logodel.png')); ?>" src="<?php echo e($logo_thumbnail ?? asset('web/images/logodel.png')); ?>" alt="Canvas Logo">
                    </a>
                </div>
                <a href="<?php echo e(route('web.home')); ?>" class="text-nowrap ms-3 my-4" style="margin-right:-90px;">
                    <div class="text-uppercase" style="color: #13005a; font-size: 15px; font-weight: 600"><?php echo e($logo->faculty ?? 'FAKULTAS VOKASI'); ?></div>
                    <div class="text-uppercase" style="font-size: 15px; font-weight: semi-bold;"><?php echo e($logo->university ?? 'Institut Teknologi Del'); ?></div>
                </a>
            </div><!-- #logo end -->

            <div class="header-misc">
                <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('web.auth.index')); ?>" class="button button-small button-rounded button-blue" style="margin-right: 40px !important">Login</a>
                <?php else: ?>
                
                <?php endif; ?>
                <!-- Top Search
                ============================================= -->
                <div id="top-search" class="d-none header-misc-icon">
                    <a href="#" id="top-search-trigger"><i class="uil uil-search"></i><i class="bi-x-lg"></i></a>
                </div><!-- #top-search end -->

                <!-- Top Cart
                ============================================= -->
                <div id="top-cart" class="header-misc-icon d-none">
                    <a href="#" id="top-cart-trigger"><i class="uil uil-shopping-bag"></i><span class="top-cart-number">5</span></a>
                    <div class="top-cart-content">
                        <div class="top-cart-title">
                            <h4>Shopping Cart</h4>
                        </div>
                        <div class="top-cart-items">
                            <div class="top-cart-item">
                                <div class="top-cart-item-image">
                                    <a href="#"><img src="#" alt="Blue Round-Neck Tshirt"></a>
                                </div>
                                <div class="top-cart-item-desc">
                                    <div class="top-cart-item-desc-title">
                                        <a href="#">Blue Round-Neck Tshirt with a Button</a>
                                        <span class="top-cart-item-price d-block">$19.99</span>
                                    </div>
                                    <div class="top-cart-item-quantity">x 2</div>
                                </div>
                            </div>
                            <div class="top-cart-item">
                                <div class="top-cart-item-image">
                                    <a href="#"><img src="#" alt="Light Blue Denim Dress"></a>
                                </div>
                                <div class="top-cart-item-desc">
                                    <div class="top-cart-item-desc-title">
                                        <a href="#">Light Blue Denim Dress</a>
                                        <span class="top-cart-item-price d-block">$24.99</span>
                                    </div>
                                    <div class="top-cart-item-quantity">x 3</div>
                                </div>
                            </div>
                        </div>
                        <div class="top-cart-action">
                            <span class="top-checkout-price">$114.95</span>
                            <a href="#" class="button button-3d button-small m-0">View Cart</a>
                        </div>
                    </div>
                </div><!-- #top-cart end -->

            </div>

            <div class="primary-menu-trigger">
                <button class="cnvs-hamburger" type="button" title="Open Mobile Menu">
                    <span class="cnvs-hamburger-box"><span class="cnvs-hamburger-inner"></span></span>
                </button>
            </div>

            <!-- Primary Navigation
            ============================================= -->
            <nav class="primary-menu me-lg-auto">

                <ul class="menu-container">
                    <li class="menu-item">
                        <a class="menu-link" href="<?php echo e(route('web.home')); ?>"><div>Beranda</div></a>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="<?php echo e(route('web.tentang')); ?>"><div>Tentang</div></a>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="javascript:;"><div>Program Studi <i class="bi-chevron-down"></i></div></a>
                        <ul class="sub-menu-container">
                            <?php $__currentLoopData = \App\Models\CategoryProdi::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="menu-item">
                                <a class="menu-link" href="<?php echo e(route('web.program', $category->slug)); ?>"><div><?php echo e($category->name); ?></div></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="javascript:;"><div>Civitas <i class="bi-chevron-down"></i></div></a>
                        <ul class="sub-menu-container">
                            <li class="menu-item">
                                <a class="menu-link" href="<?php echo e(route('web.civitas.dosen')); ?>"><div>Dosen</div></a>
                            </li>
                            <li class="menu-item">
                                <a class="menu-link" href="<?php echo e(route('web.civitas.staf')); ?>"><div>Staff</div></a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="<?php echo e(route('web.berita')); ?>"><div>Berita</div></a>
                    </li>
                    <li class="menu-item">
                        <a class="menu-link" href="javascript:;"><div>Aktivitas Mahasiswa <i class="bi-chevron-down"></i></div></a>
                        <ul class="sub-menu-container">
                            <?php $__currentLoopData = \App\Models\Account\UserCategory::where('role', 6)->where('is_active', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $himpunan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="menu-item">
                                <a class="menu-link" href="<?php echo e(route('web.activity', $himpunan->slug)); ?>"><div><?php echo e($himpunan->name); ?></div></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <?php if(auth()->guard()->guest()): ?>
                    
                    <?php else: ?>
                    <li class="menu-item">
                        <a class="menu-link" href="javascript:;"><div><i class="bi bi-person-circle fs-4"></i> <i class="bi-chevron-down"></i></div></a>
                        <ul class="sub-menu-container">
                            
                                <li class="menu-item">
                                    <a class="menu-link" href="<?php echo e(route('office.dashboard.index')); ?>">
                                        <div><i class="fa-solid fa-table-columns"></i><?php echo e(auth()->user()->name); ?></div>
                                    </a>
                                </li>
                                <hr class="p-0 m-0">
                                <li class="menu-item">
                                    
                                    <a class="menu-link" href="<?php echo e(route('web.auth.logout')); ?>">
                                        <div><i class="fa-solid fa-right-from-bracket fa-rotate-180"></i>Keluar</div>
                                    </a>
                                </li>
                            
                        </ul>
                    </li>
                    <?php endif; ?>
                    
                </ul>

            </nav><!-- #primary-menu end -->

            <form class="top-search-form" action="search.html" method="get">
                <input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter.." autocomplete="off">
            </form>

        </div>
    </div>
    <div class="header-wrap-clone"></div>
</header>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/themes/web/header.blade.php ENDPATH**/ ?>