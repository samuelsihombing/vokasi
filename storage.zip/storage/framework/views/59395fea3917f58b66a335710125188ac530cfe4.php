<div id="kt_app_footer" class="app-footer">
    <!--begin::Footer container-->
    <div class="app-container container-fluid d-flex flex-column flex-md-row flex-center flex-md-stack py-3">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-dark fw-semibold me-1">2023&copy;</span>
            <a href="<?php echo e(route('web.home')); ?>" target="_blank" class="text-gray-800 text-hover-primary"><?php echo e(config('app.name')); ?></a>
        </div>
        <!--end::Copyright-->
        <!--begin::Menu-->
        
        <!--end::Menu-->
    </div>
    <!--end::Footer container-->
</div>
<?php /**PATH C:\laragon\www\vokasi\resources\views/themes/app/footer.blade.php ENDPATH**/ ?>