<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Identitas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6 transition-fade">
        <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Identitas</h1>
                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('office.dashboard.index')); ?>" class="menu-link text-gray-800 text-hover-primary">Dasbor</a>
                    </li>
                    <li class="breadcrumb-item">
                        <span class="bullet bg-gray-800 w-5px h-2px"></span>
                    </li>
                    <li class="breadcrumb-item text-gray-800"><?php echo e($data->name); ?></li>
                    <li class="breadcrumb-item">
                        <span class="bullet bg-gray-800 w-5px h-2px"></span>
                    </li>
                    <li class="breadcrumb-item text-gray-800">Identitas</li>
                </ul>
            </div>
        </div>
    </div>
    <div id="kt_app_content" class="app-content flex-column-fluid transition-fade">
        <div id="kt_app_content_container" class="app-container container-fluid">
            <form id="form_input" class="form" data-redirect-url="<?php echo e(route('office.dashboard.index')); ?>" action="<?php echo e(route('office.staff.identitas.update')); ?>" method="PATCH">
                <div class="card mb-5">
                    <div class="card-body">
                        <h4 class="mb-5">Data Diri</h4>
                        <div class="row mb-10">
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Nama Staf</label>
                                <input type="text" class="form-control form-control-solid mb-3" name="name" id="name" value="<?php echo e($data->name); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Posisi</label>
                                <select name="user_category_id" id="staf_position" class="form-select form-select-solid">
                                    <option disabled selected>Pilih Posisi</option>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($data->user_category_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Tempat Lahir</label>
                                <input type="text" class="form-control form-control-solid mb-3" name="place_birth" id="place_birth" value="<?php echo e($data->place_birth); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Tanggal Lahir</label>
                                <input type="date" class="form-control form-control-solid mb-3" name="date_birth" id="date_birth" value="<?php echo e($data->date_birth); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Email</label>
                                <input type="text" class="form-control form-control-solid mb-3" name="email" id="email" value="<?php echo e($data->email); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">ID Karyawan</label>
                                <input type="text" class="form-control form-control-solid mb-3" name="employee_id" id="employee_id" value="<?php echo e($data->employee_id); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="fw-semibold fs-6 mb-2">No Handphone</label>
                                <input type="tel" class="form-control form-control-solid mb-3" name="phone" id="phone" value="<?php echo e($data->phone); ?>">
                            </div>
                            <div class="col-12 mb-4">
                                <label class="fw-semibold fs-6 mb-2">Keahlian</label>
                                <input id="skill" type="hidden" name="skill" value="<?php echo e($data->skill); ?>">
                                <trix-editor input="skill"></trix-editor>
                            </div>
                            <div class="col-md-6">
                                <label class="d-block fw-semibold fs-6 mb-2">Gambar</label>
                                <img
                                    src="<?php echo e($data->avatar ? Storage::url($data->avatar) : ''); ?>"
                                    data-src="<?php echo e($data->avatar ? Storage::url($data->avatar) : ''); ?>"
                                    class="lozad rounded mb-3 <?php echo e($data->avatar ?? 'd-none'); ?>"
                                    id="avatar-image" style="height: 200px;"
                                />
                                <input type="file" class="form-control form-control-solid mb-3" name="avatar" id="avatar">
                            </div>
                        </div>
                        <div class="text-center pt-15">
                            <a href="<?php echo e(route('office.dashboard.index')); ?>" class="menu-link btn btn-light me-3">Batal</a>
                            <button id="tombol_simpan" onclick="handle_post('#tombol_simpan','#form_input');" class="btn btn-primary">
                                <span class="indicator-label">Simpan</span>
                                <span class="indicator-progress">Harap tunggu...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php $__env->startSection('custom_js'); ?>
    <script type="text/javascript">
        obj_date('date_birth')
        obj_select('staf_position')

        $(document).ready(function() {
            if ($("#avatar").length > 0) {
                $("#avatar").change(function(e) {
                    e.preventDefault();
                    if ($("#avatar-image").attr("src") === "") {
                        $("#avatar-image").removeClass("d-none")
                    }
                    let reader = new FileReader();
                    reader.onload = (e) => {
                        $("#avatar-image").attr("src", e.target.result);
                    }
                    reader.readAsDataURL(this.files[0]);
                });
            }
        });
    </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/app/staff_profile/personal/input.blade.php ENDPATH**/ ?>