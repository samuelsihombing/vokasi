<?php
    use App\Models\Appearance\Footer;
    $footer = Footer::where('is_active', true);
    $about_section = Footer::where('section', 'tentang')->get();
    $prodi_section = Footer::where('section', 'program studi')->get();
    $aktivitas_section = Footer::where('section', 'aktivitas mahasiswa')->get();
    $link = App\Models\Setting\Logo::where('is_active', true)->first();
?>

<footer id="footer" style="background-color :#00337C">
    <div class="container">
        <!-- Footer Widgets ============================================= -->
        <div class="footer-widgets-wrap">
            <div class="row col-mb-50">
                <div class="col-lg-8">
                    <div class="row col-mb-50">
                        <?php if($about_section->count() > 0): ?>
                        <div class="col-md-4">
                            <div class="widget widget_links">
                                <h4 class="text-white">Tentang</h4>
                                <ul class="text-white">
                                    <?php $__currentLoopData = $about_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $url = $item->url;
                                        if ((strpos($url, "route('") !== false) || (strpos($url, 'route("') !== false)) {
                                            eval("\$url = $url;");
                                        }
                                    ?>
                                    <li><a class="text-white" href="<?php echo e($url ?? '#'); ?>"><?php echo e($item->text); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="col-md-4">
                            <div class="widget widget_links">
                                <h4 class="text-white">Tentang</h4>
                                <ul class="text-white">
                                    <li><a class="text-white" href="<?php echo e(route('web.tentang')); ?>#sejarah">Sejarah</a></li>
                                    <li><a class="text-white" href="<?php echo e(route('web.tentang')); ?>#visi-misi">Visi dan Misi</a></li>
                                    <li><a class="text-white" href="<?php echo e(route('web.tentang')); ?>#struktur">Struktur Organisasi</a></li>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($prodi_section->count() > 0): ?>
                        <div class="col-md-4">
                            <div class="widget widget_links">
                                <h4 class="text-white">Program Studi</h4>
                                <ul class="text-white">
                                    <?php $__currentLoopData = $prodi_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $url = $item->url;
                                        if ((strpos($url, "route('") !== false) || (strpos($url, 'route("') !== false)) {
                                            eval("\$url = $url;");
                                        }
                                    ?>
                                    <li><a class="text-white" href="<?php echo e($url ?? '#'); ?>"><?php echo e($item->text); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="col-md-4">
                            <div class="widget widget_links">
                                <h4 class="text-white">Program Studi</h4>
                                <ul class="text-white">
                                    <?php $__currentLoopData = \App\Models\CategoryProdi::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a class="text-white" href="<?php echo e(route('web.program', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($aktivitas_section->count() > 0): ?>
                        <div class="col-md-4">
                            <div class="widget widget_links">
                                <h4 class="text-white">Aktivitas Mahasiswa</h4>
                                <ul class="text-white">
                                    <?php $__currentLoopData = $aktivitas_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $url = $item->url;
                                        if ((strpos($url, "route('") !== false) || (strpos($url, 'route("') !== false)) {
                                            eval("\$url = $url;");
                                        }
                                    ?>
                                    <li><a class="text-white" href="<?php echo e($url ?? '#'); ?>"><?php echo e($item->text); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="col-md-4">
                            <div class="widget widget_links">
                                <h4 class="text-white">Aktivitas Mahasiswa</h4>
                                <ul class="text-white">
                                    <li><a class="text-white" href="<?php echo e(route('web.activity', 'himatek')); ?>">HIMATEK</a></li>
                                    <li><a class="text-white" href="<?php echo e(route('web.activity', 'himatif')); ?>">HIMATIF</a></li>
                                    <li><a class="text-white" href="<?php echo e(route('web.activity', 'himatera')); ?>">HIMATERA</a></li>
                                </ul>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="row col-mb-50">
                        <div class="col-md-5 col-lg-12">
                            <div class="widget subscribe-widget">
                                <h4 class="text-white">Kritik dan Saran</h4>
                                <h5 class="text-white">Memiliki kritik dan saran mengenai Fakultas Vokasi Institut Teknologi Del, kirimkan komentar mu dibawah ini !</h5>
                                <div class="widget-subscribe-form-result"></div>
                                <form id="comment-form" method="POST" class="mb-0">
                                    <div class="input-group mx-auto">
                                        <div class="input-group-text"><i class="bi-envelope-plus"></i></div>
                                        <input type="text" id="comment" name="body" class="form-control" placeholder="Masukkan komentar Anda" required>
                                        
                                        <button id="submit-comment" class="btn btn-light" type="button">Kirim</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- .footer-widgets-wrap end -->
    </div>
    <!-- Copyrights ============================================= -->
    <div id="copyrights" style="background-color :#00337C">
        <div class="container">
            <div class="row col-mb-30">
                <div class="col-md-6 text-center text-md-start text-white">
                    Copyrights &copy; 2023 All Rights Reserved
                    
                </div>
                <div class="col-md-6 text-center">
                    <?php if($link != null): ?>
                    <div class="d-flex justify-content-center justify-content-md-end mb-2 me-md-5">
                        <?php if($link->facebook_url != null): ?>
                        <a href="<?php echo e($link->facebook_url); ?>" class="social-icon border-transparent si-small h-bg-facebook text-white">
                            <i class="fa-brands fa-facebook-f"></i>
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                        <?php endif; ?>
                        <?php if($link->instagram_url != null): ?>
                        <a href="<?php echo e($link->instagram_url); ?>" class="social-icon border-transparent si-small h-bg-instagram text-white">
                            <i class="fa-brands fa-instagram"></i>
                            <i class="fa-brands fa-instagram"></i>
                        </a>
                        <?php endif; ?>
                        <?php if($link->youtube_url != null): ?>
                        <a href="<?php echo e($link->youtube_url); ?>" class="social-icon border-transparent si-small h-bg-youtube text-white">
                            <i class="fa-brands fa-youtube"></i>
                            <i class="fa-brands fa-youtube"></i>
                        </a>
                        <?php endif; ?>
                        <?php if($link->linkedin_url != null): ?>
                        <a href="<?php echo e($link->linkedin_url); ?>" class="social-icon border-transparent si-small me-0 h-bg-linkedin text-white">
                            <i class="fa-brands fa-linkedin"></i>
                            <i class="fa-brands fa-linkedin"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- #copyrights end -->
</footer>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/themes/web/footer.blade.php ENDPATH**/ ?>