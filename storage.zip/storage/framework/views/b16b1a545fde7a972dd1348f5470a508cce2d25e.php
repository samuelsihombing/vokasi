<?php if (isset($component)) { $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48 = $component; } ?>
<?php $component = App\View\Components\WebLayout::resolve(['title' => 'program '.e($category->name ?? '-').''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('web-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\WebLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Page Title
  ============================================= -->
    <section class="page-title page-title-parallax parallax dark">
        <div class="container">
            <div class="page-title-row">

                <div class="page-title-content">
                    <h2>Program Studi <?php echo e($category->name ?? '-'); ?></h2>
                    <span>
                        <?php echo $program->definisi ?? '-'; ?>

                    </span>
                </div>
            </div>
        </div>
    </section><!-- .page-title end -->
    <!-- Content
  ============================================= -->
    <section id="content" class="pb-5">
        <div class="container">
            <div id="section-features" class=" page-section" style="margin-top: -35px">
                <div style="margin-top: -20px; border-top:3px; padding-top: 30px">
                    <h3 style="color: #003966"><b>SEJARAH</b></h3>
                </div>
                <hr class="col-4" style="margin-top: -20px; padding: 1px; border-top: 5px solid; color:#EE771D">
                <p>
                    <?php echo $program->sejarah ?? '-'; ?>

                </p>
            </div>
        </div>
        <div style="background: #003966">
            <div class="container">
                <div id="section-features" class=" page-section">
                    <div style="border-top:3px; padding-top: 30px">
                        <h3 style="color: white"><b>Visi dan Misi D3 - Teknologi Informasi</b></h3>
                    </div>

                    <hr class="col-4" style="margin-top: -20px; padding: 1px; border-top: 5px solid; color:#EE771D">
                    <div class="row" style="margin-top: 20px">
                        <div class="col-6 col-md-6" id="color-white-important">
                            <h4 style="color: white"><b> Visi </b></h4>
                            <p style="margin-top: -20px; color: white !important;">
                                <?php echo $program->visi ?? '-'; ?>

                            </p>
                        </div>
                        <div class="col-6 col-md-6" id="color-white-important">
                            <h4 style="color: white"><b> Misi </b></h4>
                            <p style="margin-top: -20px; color: white !important;">
                                <?php echo $program->misi ?? '-'; ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div id="section-features" class=" page-section">
                <div style="border-top:3px; padding-top: 30px">
                    <h3 style="color: #003966"><b>Tujuan Profil Lulusan</b></h3>
                </div>
                <hr class="col-4" style="margin-top: -20px; padding: 1px; border-top: 5px solid; color:#EE771D">
                <div class="col-md-6" id="color-black-important">
                    <?php echo $program->tujuan ?? '-'; ?>

                </div>
                <?php if($program): ?>
                    <?php if($program->link != null): ?>
                    <div class="mt-4">
                        <span>Kunjungi link berikut untuk informasi lebih lanjut: </span>
                        <a href="<?php echo e($program->link); ?>" style="color: #0081e3" target="_blank"><?php echo e($program->link); ?></a>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

        </div>
    </section><!-- #content end -->

    <script>
        document.querySelectorAll('#color-white-important *').forEach(function(node) {
            node.style.color = 'white';
        });
        document.querySelectorAll('#color-black-important *').forEach(function(node) {
            node.style.color = 'black';
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48)): ?>
<?php $component = $__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48; ?>
<?php unset($__componentOriginal4f561617d80b81635ce1c372fc1de3f039937f48); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/web/program/main.blade.php ENDPATH**/ ?>