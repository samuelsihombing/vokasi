<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => ''.e($data->id ? 'Perbarui' : 'Tambah').' Pengajaran dan Pembimbingan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6 transition-fade">
        <div id="kt_app_toolbar_container" class="app-container container-fluid d-flex flex-stack">
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Pengajaran dan Pembimbingan</h1>
                <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('office.dashboard.index')); ?>" class="menu-link text-gray-800 text-hover-primary">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <span class="bullet bg-gray-800 w-5px h-2px"></span>
                    </li>
                    <li class="breadcrumb-item text-gray-800"><?php echo e($dosen->name); ?></li>
                    <li class="breadcrumb-item">
                        <span class="bullet bg-gray-800 w-5px h-2px"></span>
                    </li>
                    <li class="breadcrumb-item text-gray-800">Pengajaran dan Pembimbingan</li>
                    <li class="breadcrumb-item">
                        <span class="bullet bg-gray-800 w-5px h-2px"></span>
                    </li>
                    <li class="breadcrumb-item text-gray-800"><?php echo e($data->id ? 'Perbarui' : 'Tambah'); ?></li>
                </ul>
            </div>
            
        </div>
    </div>
    <div id="kt_app_content" class="app-content flex-column-fluid transition-fade">
        <div id="kt_app_content_container" class="app-container container-fluid">
            <form id="form_input" class="form" data-redirect-url="<?php echo e(route('office.dosen.teaching_mentoring.index')); ?>" action="<?php echo e($data->id ? route('office.dosen.teaching_mentoring.update', $data->id) : route('office.dosen.teaching_mentoring.store')); ?>" method="<?php echo e($data->id ? 'PATCH' : 'POST'); ?>">
                <div class="card mb-5">
                    <div class="card-body">
                        <div class="row mb-10">
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e($dosen->id); ?>">
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Kategori</label>
                                <select name="category" id="category" class="form-select form-select-solid" data-hide-search="true" data-hide-search="true">
                                    <option disabled selected>Pilih Kategori</option>
                                    <option value="Pengajaran" <?php echo e($data->category == 'Pengajaran' ? 'selected' : ''); ?>>Pengajaran</option>
                                    <option value="Pembimbingan" <?php echo e($data->category == 'Pembimbingan' ? 'selected' : ''); ?>>Pembimbingan</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Judul</label>
                                <input type="text" class="form-control form-control-solid mb-3" name="title" id="title" value="<?php echo e($data->title); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="required fw-semibold fs-6 mb-2">Tahun</label>
                                <input type="text" class="form-control form-control-solid number_only mb-3" name="year" id="year" value="<?php echo e($data->year); ?>">
                            </div>
                            <div class="col-md-12">
                                <label class="fw-semibold fs-6 mb-2">Nama Mahasiswa</label>
                                <input id="student_name" type="hidden" name="student_name" value="<?php echo e($data->student_name); ?>">
                                <trix-editor input="student_name"></trix-editor>
                            </div>
                        </div>
                        <div class="text-center pt-15">
                            <a href="<?php echo e(route('office.dosen.teaching_mentoring.index')); ?>" class="menu-link btn btn-light me-3">Batal</a>
                            <button id="tombol_simpan" onclick="handle_post('#tombol_simpan','#form_input');" class="btn btn-primary">
                                <span class="indicator-label">Simpan</span>
                                <span class="indicator-progress">Harap tunggu...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startSection('custom_js'); ?>
        <script>
            obj_select("category");
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/pages/app/dosen_profile/teaching_mentoring/input.blade.php ENDPATH**/ ?>