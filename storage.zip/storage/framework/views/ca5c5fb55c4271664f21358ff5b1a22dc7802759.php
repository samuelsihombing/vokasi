<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Halaman Masuk'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex flex-column flex-lg-row-fluid w-lg-450 w-100 p-10 order-2 order-lg-1">
        <div class="d-flex flex-center flex-column flex-lg-row-fluid">
            <div class="d-flex justify-content-center">
                <div style="text-align: center">
                    <img src="<?php echo e(asset('web/images/logodel.png')); ?>" alt="Logo IT Del" style="width: 70px; height:auto">
                    <h3 style="padding: 30px">Sistem Informasi Fakultas Vokasi</h3>
                    <hr>
                </div>
            </div>
            <div class="w-lg-450px w-sm-75 w-md-50 w-100 p-10">
                <form class="form w-100" novalidate="novalidate" id="form_login" data-redirect-url="<?php echo e(route('office.dashboard.index')); ?>" action="<?php echo e(route('office.auth.login')); ?>">
                    <div class="fv-row mb-8">
                        <input type="email" placeholder="Email" id="email" name="email" autocomplete="email" class="form-control bg-transparent" data-login="1" data-validation="The email field is required" data-format="The email must be a valid email address" autofocus />
                    </div>
                    <div class="fv-row mb-3">
                        <input type="password" placeholder="Password" id="password" name="password" autocomplete="off" class="form-control bg-transparent" data-cms-translate="input-password" data-login="2"  data-validation="The password field is required" data-format="The password must be at least 8 characters" />
                    </div>
                    
                    <div class="row mb-10 mt-10">
                        <div class="col-md-6 d-flex justify-content-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('Ingat saya')); ?>

                                </label>
                            </div>
                        </div>
                        <div class="col-md-6 d-flex justify-content-end">
                            <button onclick="handle_post('#tombol_login','#form_login')" id="tombol_login" class="btn btn-primary">
                                <span class="indicator-label">Login</span>
                                <span class="indicator-progress">Tunggu...
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\vokasi\resources\views/pages/app/auth/login.blade.php ENDPATH**/ ?>