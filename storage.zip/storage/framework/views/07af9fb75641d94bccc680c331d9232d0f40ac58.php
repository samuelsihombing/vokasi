<?php if(auth()->guard()->guest()): ?>
    <?php $__currentLoopData = $themes->javascript->where('is_active',true)->where('is_guest',true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->is_editable == 1): ?>
            <script type="text/javascript">
                <?php echo $item->file; ?>

            </script>
        <?php else: ?>
            <?php echo $item->file; ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(auth()->guard()->check()): ?>
    <?php $__currentLoopData = $themes->javascript->where('is_active',true)->where('is_auth',true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->is_editable == 1): ?>
            <script type="text/javascript">
                <?php echo $item->file; ?>

            </script>
        <?php else: ?>
            <?php echo $item->file; ?>

        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<script src="<?php echo e(asset('app/js/myScript.js')); ?>"></script>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/themes/app/js.blade.php ENDPATH**/ ?>