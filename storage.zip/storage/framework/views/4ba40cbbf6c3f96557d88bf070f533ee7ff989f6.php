<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <?php $__currentLoopData = $themes->stylesheet->where('is_active',true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $item->file; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('owl-carousel/dist/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('owl-carousel/dist/assets/owl.theme.default.min.css')); ?>">
    <style>
        .photos{
            width:100%;
            aspect-ratio:8/2;
            object-fit:contain;
            /* mix-blend-mode: color-burn; */
        }
        .truncate {
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }
    </style>
    <?php if(request()->is('tentang-kami')): ?>
    <link rel="stylesheet" href="<?php echo e(asset('web/css/timline-custom.css')); ?>">
    <?php endif; ?>
    <title><?php echo e(config('app.name') . ': ' .$title ?? config('app.name')); ?></title>
</head>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/themes/web/head.blade.php ENDPATH**/ ?>