<div class="pagination d-flex justify-content-between">
    
    <?php if(!$paginator->onFirstPage()): ?>
        <a class="btn btn-outline-secondary me-auto" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">&larr; Sebelumnya</a>
    <?php endif; ?>

    
    <?php if($paginator->hasMorePages()): ?>
        <a class="btn btn-outline-secondary ms-auto" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Selanjutnya &rarr;</a></li>
    <?php endif; ?>
</div>
<?php /**PATH D:\xampp\htdocs\vokasi\resources\views/themes/web/pagination.blade.php ENDPATH**/ ?>